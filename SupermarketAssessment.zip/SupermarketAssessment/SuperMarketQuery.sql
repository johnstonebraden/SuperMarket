Create Database SuperMarket
Use SuperMarket
Create table Accounts
(UserID int Identity(1,1) Primary Key,
Username VarChar(20),
Pass_Word VarChar(15)
);
Insert Into Accounts Values ('admin','password')
Insert Into Accounts Values ('CDHamilton','password')
Insert Into Accounts Values ('CDTeAroha','password')
--Select * from Accounts

--drop table Accounts
Create table Products
(ItemID Int Identity(100000,1) Primary Key,
ItemName VarChar(50),
ItemType VarChar(50),
ItemCount int,
);
--drop table Products
--Select * From Products
Insert Into Products Values ('Coke', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Coke Zero', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Diet Coke', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Fanta', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Sprite', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Sprite Zero', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Lemonade', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Cola', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Ginger Ale', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Orange', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Raspberry', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Lemonade', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Diet-Lemonade', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('HB Lemon Crush', 'Drinks-NonAlcoholic', 0)
Insert Into Products Values ('Heineken 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Heineken 24P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Amstel 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Tiger 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Kingfisher 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Carlsberg 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Corona 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Budweiser 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Guinness 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Stella Artois 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Bescks 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Speights 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Speights 24P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Tui 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Speights 24P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Lion Red 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Lion Red 24P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Waikato Draught 12P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Waikato Draught 24P', 'Drinks-Alcoholic', 0)
Insert Into Products Values ('Weet-Bix 1.2kg', 'Cereal', 0)
Insert Into Products Values ('Weet-Bix 750g', 'Cereal', 0)
Insert Into Products Values ('RiceBubbles 500g', 'Cereal', 0)
Insert Into Products Values ('CocoPops 500g', 'Cereal', 0)
Insert Into Products Values ('Nutragrain 500g', 'Cereal', 0)
Insert Into Products Values ('HB Rolled Oats', 'Cereal', 0)
Insert Into Products Values ('Special K 500g', 'Cereal', 0)

--Update Products Set ItemCount = 0
