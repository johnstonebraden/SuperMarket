﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketAssessment
{
    /// <summary>
    /// Interaction logic for Export.xaml
    /// </summary>
    public partial class Export : Window
    {        
        SuperMarketEntities entities = new SuperMarketEntities();
        public Export()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            //goes back to main window
            Items win2 = new Items();
            win2.Show();
            this.Close();
        }

        private void cbItem_DropDownClosed(object sender, EventArgs e)
        {
            //loads datagrid with correct itemtype
            var itemProducts = (from items in entities.Products
                                where items.ItemType == cbItem.Text
                                select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount }).ToList();
            dgProducts.ItemsSource = itemProducts;
            cbSelectAll.IsChecked = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //loading dropdown box
            var itemList = (from i in entities.Products
                            select i.ItemType).Distinct().ToList();
            cbItem.ItemsSource = itemList;

            //loading datagrid
            var itemProducts = from items in entities.Products
                               select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
            dgProducts.ItemsSource = itemProducts.ToList();
            cbSelectAll.IsChecked = true;
        }

        private void cbSelectAll_Checked(object sender, RoutedEventArgs e)
        {
            //selects all the itemtypes so user can export a full list
            var itemProducts = from items in entities.Products
                               select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
            dgProducts.ItemsSource = itemProducts.ToList();

            cbItem.Text = "";
        }

        private void btnSendToFile_Click(object sender, RoutedEventArgs e)
        {
            //getting name of file to create
            string fileName;
            if(cbItem.Text != "")
            {
                fileName = cbItem.Text;
            }
            else
            {
                fileName = "Products";
            }
            //sends the current datagrid to a excel file then shows a message
            DataGrid dg = dgProducts;
            dg.SelectAllCells();
            dg.ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader;
            ApplicationCommands.Copy.Execute(null, dg);
            dg.UnselectAllCells();
            String Clipboardresult = (string)Clipboard.GetData(DataFormats.CommaSeparatedValue);
            StreamWriter swObj = new StreamWriter(fileName + ".csv");
            swObj.WriteLine(Clipboardresult);
            swObj.Close();
            Process.Start(fileName + ".csv");

            MessageBox.Show("Data exported");
        }
    }
}
