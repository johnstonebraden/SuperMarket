﻿using Microsoft.VisualBasic.FileIO;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketAssessment
{
    /// <summary>
    /// Interaction logic for Import.xaml
    /// </summary>
    public partial class Import : Window
    { 
        DataTable csvData = new DataTable();
        SuperMarketEntities entities = new SuperMarketEntities();
        public Import()
        {
            InitializeComponent();
            
        }
        string FilePath;

        public DataTable GetDataTabletFromCSVFile(string csv_file_path)     //reading the file and creating a datatable
        {
            csvData.Clear();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });    //setting where to split the lones into columns
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);
            }
            return csvData;
            
        }


        private void btnChooseFile_Click(object sender, RoutedEventArgs e)
        {
            csvData.Clear();
            Microsoft.Win32.OpenFileDialog opf = new Microsoft.Win32.OpenFileDialog();   //selecting the file and displaying in datagrid
            
            if (opf.ShowDialog() == true)
            {
                FilePath = opf.FileName;
            }
            
            GetDataTabletFromCSVFile(FilePath);
            dgImport.ItemsSource = csvData.DefaultView;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            Items i = new Items();
            i.Show();
            this.Close();
        }

        private void btnUpdateFromFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                foreach (DataRow i in csvData.Rows)    //loop to go through each item in datatable 
                {
                    int id =  Convert.ToInt32(i[0].ToString());
                    //System.Windows.MessageBox.Show(i[0].ToString());
                    //get item

                    var product = (from p in entities.Products
                                where p.ItemID == id
                                select p).FirstOrDefault();
                    if (product != null)
                    {
                        //updating item
                        product.ItemName = i[1].ToString();
                        product.ItemType = i[2].ToString();
                        product.ItemCount = Convert.ToInt32(i[3]);
                    }
                    else if (product == null)
                    {
                        Product prodObj = new Product();

                        prodObj.ItemName = i[1].ToString();
                        prodObj.ItemType = i[2].ToString();
                        prodObj.ItemCount = Convert.ToInt32(i[3]);

                        entities.Products.Add(prodObj);
                        entities.SaveChanges();
                    }
            }
                //save changes
            entities.SaveChanges();
                System.Windows.MessageBox.Show("Data updated");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);  //shows exception message
            }
            
        }
    }
}
