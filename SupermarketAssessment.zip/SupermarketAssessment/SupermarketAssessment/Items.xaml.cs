﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.VisualBasic.FileIO;


namespace SupermarketAssessment
{
    /// <summary>
    /// Interaction logic for Items.xaml
    /// </summary>
    public partial class Items : Window
    {
        SuperMarketEntities entities = new SuperMarketEntities();
        public Items()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //loading dropdown box
            var itemList = (from i in entities.Products  
                           select i.ItemType).Distinct().ToList();
            
            cbItemType.ItemsSource = itemList;
            //loading datagrid
            var itemProducts = from items in entities.Products                             
                               select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
            dgItems.ItemsSource = itemProducts.ToList();
        }

        private void dgItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //populating text boxes on selected item
            try
            {
                var row = dgItems.SelectedItems[0];
                Type type = row.GetType();

                txtItemID.Text = (string)type.GetProperty("ItemID").GetValue(row, null).ToString();
                txtItemType.Text = (string)type.GetProperty("ItemType").GetValue(row, null);
                txtItemName.Text = (string)type.GetProperty("ItemName").GetValue(row, null);
                txtItemCount.Text = (string)type.GetProperty("ItemCount").GetValue(row, null).ToString();

            }
            catch (Exception)
            {

            }
        }

        private void RefreshProducts()
        {
            //refreshing dropdown box and the gatagrid
            var itemProducts = from items in entities.Products                               
                               select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
            dgItems.ItemsSource = itemProducts.ToList();


            var itemList = (from i in entities.Products
                            select i.ItemType).Distinct().ToList();

            cbItemType.ItemsSource = itemList;
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            //search function
            var itemProducts = from items in entities.Products
                               where items.ItemName.Contains(txtSearch.Text)
                               select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
            dgItems.ItemsSource = itemProducts.ToList();

            //clears the dropdown box when something is searched for
            cbItemType.Text = "";
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            //going to export window
            Export exp = new Export();
            exp.Show();
            this.Close();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            //adding an item on button click, clearing txt boxes then shwoing a message
            Product prodObj = new Product();

            prodObj.ItemName = txtItemName.Text;
            prodObj.ItemType = txtItemType.Text;
            prodObj.ItemCount = Convert.ToInt16(txtItemCount.Text);

            entities.Products.Add(prodObj);
            entities.SaveChanges();
            RefreshProducts();
            txtItemID.Clear();
            txtItemName.Clear();
            txtItemType.Clear();
            txtItemCount.Clear();

            MessageBox.Show("Item added");

        }

        private void btnDelete_Click_1(object sender, RoutedEventArgs e)
        {

            int id = Convert.ToInt32(txtItemID.Text);
            //get item
            var product = (from p in entities.Products
                           where p.ItemID == id
                           select p).First();
            //deleting
            entities.Products.Remove(product);
            //save changes
            entities.SaveChanges();
            //refresh
            RefreshProducts();

            MessageBox.Show("Item deleted");
        }

        private void btnUpdate_Click_1(object sender, RoutedEventArgs e)
        { 
            int id = Convert.ToInt32(txtItemID.Text);

            //get item
            var product = (from p in entities.Products
                           where p.ItemID == id
                           select p).First();
            //updating item
            product.ItemType = txtItemType.Text;
            product.ItemName = txtItemName.Text;
            product.ItemCount = Convert.ToInt16(txtItemCount.Text);
            //save changes
            entities.SaveChanges();
            //refresh
            RefreshProducts();
            MessageBox.Show("Item updated");
        }

        private void cbItemType_DropDownClosed(object sender, EventArgs e)
        {
            //loads data into datagrid depending on what itemtype is selected in the drop down box
            var itemProducts = (from items in entities.Products
                                where items.ItemType == cbItemType.Text
                                select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount }).ToList();
            dgItems.ItemsSource = itemProducts;
            txtSearch.Clear();

            //showing all items if itemtype = blank
            if(cbItemType.SelectedIndex == -1)
            {
                var itemProducts2 = from items in entities.Products
                                   select new { items.ItemID, items.ItemName, items.ItemType, items.ItemCount };
                dgItems.ItemsSource = itemProducts2.ToList();
            }
        }

        private void btnUpdateFromFile_Click(object sender, RoutedEventArgs e)                                       
            {
            Import im = new Import();
            im.Show();
            this.Close();
            }

        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(Properties.Resources.strHelp,"Help");
        }
    }       
}

