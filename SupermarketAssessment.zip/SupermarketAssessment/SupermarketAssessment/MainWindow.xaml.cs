﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SupermarketAssessment
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SuperMarketEntities entities = new SuperMarketEntities();
        public MainWindow()
        {
            InitializeComponent();  
        }



        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            //checking if user inputs correct username & passkey
            var result = ( from acc in entities.Accounts
                         where acc.Username == txtUsername.Text && acc.Pass_Word == pbPassword.Password
                         select acc).FirstOrDefault();

           if(result != null)
            {
                Items win2 = new Items();
                win2.Show();
                this.Close();

            }
           else
            { 
                //message shows if incorrect
                MessageBox.Show("Incorrect username or password");
                txtUsername.Clear();
                pbPassword.Clear();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //needs this blank event to prevent an error
        }
    }
}
